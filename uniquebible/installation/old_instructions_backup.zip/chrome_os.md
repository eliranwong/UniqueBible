# Latest notes on Chrome OS

Latest instructions on installation Unique Bible App Desktop version on Chrome OS is now placed at:

https://github.com/eliranwong/ChromeOSLinux/blob/main/bible/UniqueBibleApp.md
